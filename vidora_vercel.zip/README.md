# VIDORA — versi Vercel + Supabase

Website streaming video tema hitam-kuning. Video hanya dikelola admin. Tidak perlu Termux atau VPS untuk deployment.

## Apa yang diperlukan
- Akun GitHub
- Akun Vercel
- Akun Supabase

## Setup
1. Upload seluruh isi folder proyek ini ke repository GitHub.
2. Di Supabase, buat project baru.
3. Buka SQL Editor dan jalankan isi `supabase-setup.sql`.
4. Di Supabase Storage, buat bucket bernama `videos` dan tandai Public.
5. Di Supabase Project Settings → API, salin Project URL, anon/publishable key, dan service_role/secret key.
6. Di Vercel, pilih Add New → Project, import repository GitHub.
7. Tambahkan Environment Variables di Vercel:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `ADMIN_PASSWORD` (gunakan password unik yang panjang)
   - `SESSION_SECRET` (string acak panjang, jangan sama dengan password)
8. Deploy. Jika mengubah environment variables, lakukan redeploy.
9. Buka `https://nama-project.vercel.app/admin`, lalu login dengan `ADMIN_PASSWORD`.

## Batasan prototipe
- Route upload saat ini sengaja membatasi file sampai 4 MB karena request body Vercel Function memiliki batas 4.5 MB. Ini untuk menguji alur kecil saja, bukan untuk video produksi.
- Untuk video lebih besar, implementasikan direct upload ke Vercel Blob memakai token upload terbatas, atau gunakan provider video/storage yang mendukung direct upload. Jangan mengirim video besar melalui route server ini.
- Supabase Storage punya kuota dan biaya sesuai paket; cek batas paket sebelum upload.
- Ini starter untuk pengembangan, bukan produksi yang sudah diaudit. Sebelum publikasi tambahkan CSRF protection, rate limit login, validasi origin, log keamanan, dan proteksi upload. Gunakan password admin kuat.
- Jangan menyimpan `SUPABASE_SERVICE_ROLE_KEY` di kode klien atau repo publik.
- Publikasikan hanya video legal yang kamu berhak distribusikan; terapkan moderasi, prosedur laporan/takedown, aturan privasi, dan batas usia sesuai hukum setempat.
