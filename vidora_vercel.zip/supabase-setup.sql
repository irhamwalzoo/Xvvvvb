-- Run this in Supabase Dashboard -> SQL Editor.
create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text default '',
  category text default 'General',
  video_url text not null,
  thumbnail_url text,
  created_at timestamptz not null default now()
);

alter table public.videos enable row level security;

-- Public can read the video catalog. Writes are done only by server routes using service-role key.
drop policy if exists "Public can read videos" on public.videos;
create policy "Public can read videos" on public.videos
  for select to anon, authenticated using (true);

-- Create a Storage bucket named "videos" and mark it Public in Storage dashboard.
-- Do not add client upload policies. Server-only service role performs uploads/deletes.
