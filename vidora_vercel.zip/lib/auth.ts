import { cookies } from "next/headers";
import { createHmac, timingSafeEqual } from "crypto";

const COOKIE = "vidora_admin";
function signature(value: string) {
  const secret = process.env.SESSION_SECRET;
  if (!secret) throw new Error("SESSION_SECRET is not configured.");
  return createHmac("sha256", secret).update(value).digest("hex");
}
export function makeSession() {
  const value = "admin:" + Date.now().toString();
  return value + "." + signature(value);
}
export async function isAdmin() {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return false;
  const split = token.lastIndexOf(".");
  if (split < 0) return false;
  const value = token.slice(0, split);
  const sig = token.slice(split + 1);
  try {
    const expected = signature(value);
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return false;
    const timestamp = Number(value.split(":")[1]);
    return value.startsWith("admin:") && Number.isFinite(timestamp) && Date.now() - timestamp < 1000 * 60 * 60 * 24 * 7;
  } catch { return false; }
}
export const adminCookieName = COOKIE;
