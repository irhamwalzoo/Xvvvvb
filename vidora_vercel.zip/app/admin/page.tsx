import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { isAdmin } from "../../lib/auth";
import { supabaseAdmin } from "../../lib/supabase-server";
import Link from "next/link";
export const dynamic = "force-dynamic";
export default async function Admin({ searchParams }: { searchParams: Promise<{ error?: string; ok?: string }> }) {
  const { error = "", ok = "" } = await searchParams;
  const loggedIn = await isAdmin();
  let videos: any[] = [];
  if (loggedIn) {
    const result = await supabaseAdmin().from("videos").select("id,title,category,created_at").order("created_at", { ascending: false });
    videos = result.data || [];
  }
  return <main className="container"><header className="topbar"><Link className="brand" href="/"><span className="brand-mark">▶</span> VIDORA</Link><Link className="admin-link" href="/">Lihat situs</Link></header>
    {!loggedIn ? <section className="login-card"><p className="eyebrow">AREA TERBATAS</p><h1>Login admin</h1><p className="muted">Hanya admin yang dapat mengunggah video.</p>
      {error && <div className="notice error">{error === "login" ? "Password salah." : "Terjadi kesalahan. Coba lagi."}</div>}
      <form className="stack" method="post" action="/api/admin/login"><label>Password admin<input type="password" name="password" required autoComplete="current-password" /></label><button className="button">Masuk</button></form>
    </section> : <>
      <div className="admin-head"><div><p className="eyebrow">DASHBOARD</p><h1>Panel admin</h1></div><form action="/api/admin/logout" method="post"><button className="button secondary">Keluar</button></form></div>
      {ok && <div className="notice success">Video berhasil diunggah.</div>}{error && <div className="notice error">Gagal mengunggah. Periksa pengaturan storage dan database.</div>}
      <section className="admin-panel"><h2>Unggah video</h2>
        <form className="stack" action="/api/admin/upload" method="post" encType="multipart/form-data">
          <label>Judul video<input name="title" maxLength={160} required /></label>
          <label>Kategori<input name="category" maxLength={80} placeholder="Mis. Hiburan" /></label>
          <label>Deskripsi<textarea name="description" maxLength={2000} rows={3} /></label>
          <label>File video (MP4/WebM, maksimal 4 GB, bergantung paket/storage)<input type="file" name="video" accept="video/mp4,video/webm,video/ogg" required /></label>
          <button className="button">Unggah video</button>
        </form>
        <p className="muted small">Catatan: unggahan form biasa melewati batas request Vercel. Untuk file besar, tahap berikutnya perlu direct-to-Blob upload dengan token terbatas.</p>
      </section>
      <section className="admin-panel"><h2>Video terbit ({videos.length})</h2>{videos.map(v => <div className="admin-video" key={v.id}><div><strong>{v.title}</strong><p className="muted">{v.category}</p></div><form action="/api/admin/delete" method="post"><input type="hidden" name="id" value={v.id}/><button className="button danger">Hapus</button></form></div>)}</section>
    </>}
  </main>;
}
