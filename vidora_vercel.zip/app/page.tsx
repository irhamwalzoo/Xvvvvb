import Link from "next/link";
import { supabaseAdmin } from "../lib/supabase-server";

export const dynamic = "force-dynamic";
export default async function Home({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = "" } = await searchParams;
  let videos: any[] = [];
  let error = "";
  try {
    const supabase = supabaseAdmin();
    let query = supabase.from("videos").select("id,title,description,category,video_url,created_at").order("created_at", { ascending: false }).limit(100);
    if (q.trim()) query = query.or(`title.ilike.%${q.trim().replace(/[,%()]/g, "")}%,category.ilike.%${q.trim().replace(/[,%()]/g, "")}%`);
    const result = await query;
    if (result.error) error = "Database belum siap. Ikuti langkah setup di README.";
    videos = result.data || [];
  } catch { error = "Hubungkan Supabase melalui Environment Variables Vercel terlebih dahulu."; }

  return <main className="container">
    <header className="topbar">
      <Link className="brand" href="/"><span className="brand-mark">▶</span> VIDORA</Link>
      <form className="search" action="/" method="get"><input name="q" defaultValue={q} placeholder="Cari video..." /><button>Cari</button></form>
      <Link className="admin-link" href="/admin">Admin</Link>
    </header>
    <section className="hero"><p className="eyebrow">VIDEO STREAMING</p><h1>Temukan video <span>favoritmu.</span></h1><p className="muted">Katalog video pilihan, diperbarui oleh admin.</p></section>
    {error && <div className="notice">{error}</div>}
    <div className="section-heading"><h2>{q ? "Hasil pencarian" : "Video terbaru"}</h2><span>{videos.length} video</span></div>
    {videos.length ? <div className="video-grid">{videos.map((v) => <Link className="video-card" href={`/watch/${v.id}`} key={v.id}>
      <div className="thumb">{v.thumbnail_url ? <img src={v.thumbnail_url} alt="" /> : <span className="play">▶</span>}<span className="quality">VIDEO</span></div>
      <div className="video-meta"><h3>{v.title}</h3><p>{v.category || "General"} · {new Date(v.created_at).toLocaleDateString("id-ID")}</p></div>
    </Link>)}</div> : <div className="empty"><div className="empty-icon">▶</div><h3>Belum ada video</h3><p>Admin dapat masuk untuk menambahkan video pertama.</p><Link className="button" href="/admin">Buka panel admin</Link></div>}
  </main>;
}
