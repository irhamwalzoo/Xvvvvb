import Link from "next/link";
import { notFound } from "next/navigation";
import { supabaseAdmin } from "../../../lib/supabase-server";
export const dynamic = "force-dynamic";
export default async function Watch({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{10,}$/i.test(id)) notFound();
  const { data: video, error } = await supabaseAdmin().from("videos").select("*").eq("id", id).single();
  if (error || !video) notFound();
  return <main className="container"><header className="topbar"><Link className="brand" href="/"><span className="brand-mark">▶</span> VIDORA</Link><Link className="admin-link" href="/admin">Admin</Link></header>
    <Link className="back-link" href="/">← Kembali ke katalog</Link>
    <section className="watch-layout"><div className="player-wrap"><video controls playsInline preload="metadata" src={video.video_url}>Browser kamu tidak mendukung video HTML5.</video></div>
    <h1 className="watch-title">{video.title}</h1><p className="muted">{video.category || "General"} · {new Date(video.created_at).toLocaleDateString("id-ID")}</p>
    {video.description && <p className="description">{video.description}</p>}</section>
  </main>;
}
