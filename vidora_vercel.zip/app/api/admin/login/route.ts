import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { createHmac, timingSafeEqual } from "crypto";
import { adminCookieName, makeSession } from "../../../../lib/auth";
export async function POST(req: Request) {
  const form = await req.formData();
  const password = String(form.get("password") || "");
  const expected = process.env.ADMIN_PASSWORD || "";
  let valid = false;
  if (expected && password) {
    const a = Buffer.from(password); const b = Buffer.from(expected);
    valid = a.length === b.length && timingSafeEqual(a, b);
  }
  if (!valid) return NextResponse.redirect(new URL("/admin?error=login", req.url), 303);
  const jar = await cookies();
  jar.set(adminCookieName, makeSession(), { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 7 });
  return NextResponse.redirect(new URL("/admin", req.url), 303);
}
