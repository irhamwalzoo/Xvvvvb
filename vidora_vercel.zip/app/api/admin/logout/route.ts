import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { adminCookieName } from "../../../../lib/auth";
export async function POST(req: Request) {
  (await cookies()).delete(adminCookieName);
  return NextResponse.redirect(new URL("/", req.url), 303);
}
