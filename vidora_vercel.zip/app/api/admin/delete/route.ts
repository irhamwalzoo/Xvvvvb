import { NextResponse } from "next/server";
import { isAdmin } from "../../../../lib/auth";
import { supabaseAdmin } from "../../../../lib/supabase-server";
export async function POST(req: Request) {
  if (!(await isAdmin())) return NextResponse.redirect(new URL("/admin", req.url), 303);
  const form = await req.formData();
  const id = String(form.get("id") || "");
  const supabase = supabaseAdmin();
  const { data: video } = await supabase.from("videos").select("id,video_url").eq("id", id).single();
  if (video) {
    const url = new URL(video.video_url);
    const marker = "/storage/v1/object/public/videos/";
    const idx = url.pathname.indexOf(marker);
    if (idx >= 0) await supabase.storage.from("videos").remove([decodeURIComponent(url.pathname.slice(idx + marker.length))]);
    await supabase.from("videos").delete().eq("id", id);
  }
  return NextResponse.redirect(new URL("/admin", req.url), 303);
}
