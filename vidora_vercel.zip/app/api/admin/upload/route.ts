import { NextResponse } from "next/server";
import { isAdmin } from "../../../../lib/auth";
import { supabaseAdmin } from "../../../../lib/supabase-server";
export const runtime = "nodejs";
export async function POST(req: Request) {
  if (!(await isAdmin())) return NextResponse.redirect(new URL("/admin", req.url), 303);
  const form = await req.formData();
  const title = String(form.get("title") || "").trim().slice(0, 160);
  const category = String(form.get("category") || "General").trim().slice(0, 80);
  const description = String(form.get("description") || "").trim().slice(0, 2000);
  const file = form.get("video");
  if (!title || !(file instanceof File) || file.size === 0 || file.size > 4 * 1024 * 1024) {
    return NextResponse.redirect(new URL("/admin?error=upload", req.url), 303);
  }
  const allowed = ["video/mp4", "video/webm", "video/ogg"];
  if (!allowed.includes(file.type)) return NextResponse.redirect(new URL("/admin?error=upload", req.url), 303);
  const ext = file.type === "video/webm" ? "webm" : file.type === "video/ogg" ? "ogv" : "mp4";
  const filename = `${crypto.randomUUID()}.${ext}`;
  const supabase = supabaseAdmin();
  const bytes = Buffer.from(await file.arrayBuffer());
  const upload = await supabase.storage.from("videos").upload(filename, bytes, { contentType: file.type, upsert: false });
  if (upload.error) return NextResponse.redirect(new URL("/admin?error=upload", req.url), 303);
  const { data } = supabase.storage.from("videos").getPublicUrl(filename);
  const insert = await supabase.from("videos").insert({ title, category, description, video_url: data.publicUrl }).select("id").single();
  if (insert.error) {
    await supabase.storage.from("videos").remove([filename]);
    return NextResponse.redirect(new URL("/admin?error=upload", req.url), 303);
  }
  return NextResponse.redirect(new URL("/admin?ok=1", req.url), 303);
}
