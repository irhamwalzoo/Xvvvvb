import "./style.css";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "VIDORA — Video Streaming",
  description: "Temukan video favoritmu di VIDORA."
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="id"><body>{children}<footer className="footer">VIDORA · Unggah hanya video legal yang kamu berhak distribusikan.</footer></body></html>;
}
